

<?php $__env->startSection('title', '- Monte sua Placa'); ?>

<?php $__env->startSection('content'); ?>

    <div class="frames">

        <div class="page-title-content">
            <h1>Monte sua Placa</h1>
            <h5><a href="">Home</a> <span>/</span> Placas</h5>
        </div>

        <div class="container">

            <form id="placaSteps" action="<?php echo e(route('placas.create')); ?>" method="POST" enctype="multipart/form-data">

                <?php echo csrf_field(); ?>

                <div>

                    <!-- TAMANHO -->
                    <h3>Escolha o Tamanho</h3>

                    <section>

                        <div class="sizes">

                            <div class="row">

                                <?php $__currentLoopData = $placas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $placa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <div class="col-12 col-lg-4 col-md-6">

                                        <div class="size-item">
                                            <input type="radio" name="size" id="size-option-<?php echo e($placa->id); ?>" value="<?php echo e($placa->id); ?>" title="<?php echo e($placa->title); ?>" class="input-hidden radioSize" required />

                                            <label for="size-option-<?php echo e($placa->id); ?>" class="sizeOption">
                                                <img class="img-fluid" src="<?php echo e(asset('storage/' . $placa->image)); ?>" />
                                            </label>
                                        </div>

                                    </div>
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>

                        </div>

                    </section>

                    <!-- MODELO -->

                    <h3>Escolha o Modelo</h3>

                    <section>

                        <div class="models">

                        </div>

                    </section>

                    <!-- DESIGN -->

                    <h3>Escolha um Design</h3>

                    <section>

                        <div class="designs">

      
                        </div>

                    </section>

                    <!-- INFORMAÇÕES -->

                    <h3>Insira as Informações</h3>

                    <section>

                        <div class="row information">

                            <div class="col-12 col-lg-12 col-md-12">

                                <div class="row">

                                    <div class="col-lg-6 col-md-12">

                                        <div class="form-group">
                                            <label>Nome</label>
                                            <input type="text" name="name" class="form-control" placeholder="João da Silva" required>
                                        </div>

                                        <div class="form-group">
                                            <label>Data de Nascimento</label>
                                            <input type="text" name="birthdate" class="form-control data" placeholder="01/01/1950" required>
                                        </div>

                                        <div class="form-group">
                                            <label>Data de Falecimento</label>
                                            <input type="text" name="deathdate" class="form-control data" placeholder="01/01/1999" required>
                                        </div>

                                        <div class="form-group">
                                            <label>Frase</label>
                                            <textarea class="form-control" name="phrase" rows="2"></textarea>
                                        </div>

                                    </div>

                                    <div class="col-lg-6 col-md-12">

                                        <div id='img_contain'>
                                            <img id="blah" src="http://www.clker.com/cliparts/c/W/h/n/P/W/generic-image-file-icon-hi.png" />
                                        </div>

                                        <div class="input-group">
                                            <div class="custom-file">
                                                <input type="file" name="image" id="inputGroupFile01" class="imgInp custom-file-input">
                                                <label class="custom-file-label" for="inputGroupFile01">Escolha uma foto</label>
                                            </div>

                                        </div>

                                        <div class="text-center">
                                            <small>Fotos (jpg, jpeg, png)</small>
                                        </div>


                                    </div>

                                </div>

                            </div>

                    </section>


                </div>
            </form>




        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\placas\resources\views/placas/index.blade.php ENDPATH**/ ?>