<?php $__env->startSection('title', '- Frases'); ?>

<?php $__env->startSection('content'); ?>

    <div id="frases">

        <div class="container">

            <div class="page-title-content">
                <h1>Frases</h1>
                <h5><a href="">Home</a> <span>/</span> Frases</h5>
            </div>

            <div class="row">

                <div class="col-md-12">
                    <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

                <div class="col-md-12 col-sm-12">

                    <div class="card my-3">
                        <div class="card-body">
                            <blockquote class="blockquote mb-0">
                                <p>Quem tem um amigo, mesmo que um só, não importa onde se encontre, jamais sofrerá de  solidão; poderá morrer de saudades, mas não estará só.</p>
                                <footer class="blockquote-footer">Desconhecido</footer>
                            </blockquote>
                        </div>
                    </div>

                    <div class="card my-3">
                        <div class="card-body">
                            <blockquote class="blockquote mb-0">
                                <p>Quem tem um amigo, mesmo que um só, não importa onde se encontre, jamais sofrerá de  solidão; poderá morrer de saudades, mas não estará só.</p>
                                <footer class="blockquote-footer">Desconhecido</footer>
                            </blockquote>
                        </div>
                    </div>

                    <div class="card my-3">
                        <div class="card-body">
                            <blockquote class="blockquote mb-0">
                                <p>Quem tem um amigo, mesmo que um só, não importa onde se encontre, jamais sofrerá de  solidão; poderá morrer de saudades, mas não estará só.</p>
                                <footer class="blockquote-footer">Desconhecido</footer>
                            </blockquote>
                        </div>
                    </div>


                </div>


            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\placas\resources\views/frases/index.blade.php ENDPATH**/ ?>