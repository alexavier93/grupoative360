<div class="row">

    <?php $__currentLoopData = $modelos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modelo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="col-12 col-lg-4 col-md-6">
            <div class="model-item">
                <input type="radio" name="model" id="model-option-<?php echo e($modelo['id']); ?>" value="<?php echo e($modelo['id']); ?>"
                    class="input-hidden radioModel" required />
                <label for="model-option-<?php echo e($modelo['id']); ?>" class="modelOption">
                    <img class="img-fluid"
                        src="<?php echo e(asset('storage/' . $modelo['image'])); ?>" />
                </label>
            </div>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div><?php /**PATH C:\xampp\htdocs\placas\resources\views/placas/modelos.blade.php ENDPATH**/ ?>