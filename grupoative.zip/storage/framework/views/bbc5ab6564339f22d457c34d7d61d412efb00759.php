<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" href="/docs/4.0/assets/img/favicons/favicon.ico">
    <title>Grupo Ative 360 <?php echo $__env->yieldContent('title'); ?></title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/5.4.5/css/swiper.min.css" />

    <link href="<?php echo e(asset('/assets/css/app.css')); ?>" rel="stylesheet">


</head>

<body>

    <!-- START NAVBAR SECTION -->
    <!-- Header -->
    <header id="header">

        <div class="header-top">

            <div class="container">

                <div class="content">

                    <div class="row">

                        <div class="col-md-6 top-left"></div>

                        <div class="col-md-6 top-right">
                            <ul>
                                <li>
                                    <a>
                                        <i class="fab fa-whatsapp"></i>
                                        <span>+55 (11) 9 9869 0515</span>
                                    </a>
                                </li>
                                <li>
                                    <a>
                                        <i class="fas fa-envelope"></i>
                                        <span>jaison@grupoative360.com.br</span>
                                    </a>
                                </li>
                            </ul>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        <div class="header-nav">
            <!-- <div class="header-nav header-nav-pages"> -->

            <div class="container">

                <div class="row">

                    <div class="logo">

                        <?php if(route('home')): ?>
                            <a href="" class="logo-main">
                                <img src="<?php echo e(asset('assets/images/grupo-ative-360.png')); ?>" alt="">
                            </a>
                        <?php else: ?>
                            <a href="" class="logo-main">
                                <img class="img-fluid" src="<?php echo e(asset('assets/images/grupo-ative-360.png')); ?>" alt="">
                            </a>
                        <?php endif; ?>

                        <a href="" class="logo-fix">
                            <img class="img-fluid" src="<?php echo e(asset('assets/images/grupo-ative-360.png')); ?>" alt="">
                        </a>

                    </div>

                    <div class="menu">

                        <nav class="nav">
                            <ul>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('home')); ?>">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('quemsomos.index')); ?>">Quem Somos</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('servicos.index')); ?>">Serviços</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('clientes.index')); ?>">Clientes</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('contato.index')); ?>">Contato</a>
                                </li>
                            </ul>
                        </nav>

                    </div>

                    <a href="javascript:void(0)" class="sidemenu_btn d-lg-none" id="sidemenu_toggle">
                        <span></span>
                        <span></span>
                        <span></span>
                    </a>

                </div>

            </div>

        </div>

        <!--Side Nav-->
        <div class="side-menu hidden">
            <div class="inner-wrapper">
                <span class="btn-close" id="btn_sideNavClose"><i></i><i></i></span>
                <nav class="side-nav w-100">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('home')); ?>">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('quemsomos.index')); ?>">Quem Somos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('servicos.index')); ?>">Serviços</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('clientes.index')); ?>">Clientes</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('contato.index')); ?>">Contato</a>
                        </li>
                    </ul>
                </nav>

            </div>

        </div>

        <a id="close_side_menu" href="javascript:void(0);"></a>

    </header>
    <!-- Header -->

    <main role="main">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <!-- Section Contato Footer -->

    <?php if(!Request::is('contato')): ?>
        
        <section class="contato-footer py-5">

            <div class="container">

                <div class="row">

                    <div class="col-lg-6 col-md-6">
                        <img class="img-fluid w-75" src="<?php echo e(asset('assets/images/contato-home.png')); ?>">
                    </div>

                    <div class="col-lg-6 col-md-6">

                        <div class="about-content">

                            <div class="title-section"><h2>Fale conosco</h2></div>

                            <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <form action="<?php echo e(route('contato.enviaEmail')); ?>" method="POST" class="my-4">

                                <?php echo csrf_field(); ?>

                                <div class="form-group">
                                    <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('name')); ?>" placeholder="Nome">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                    
                                <div class="form-group">
                                    <input type="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>" placeholder="E-mail">
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                    
                                <div class="form-group">
                                    <input type="text" name="phone" class="form-control telefone <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('phone')); ?>" placeholder="Telefone">
                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            
                            
                                <div class="form-group">
                                    <textarea name="description" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="5" placeholder="Mensagem"><?php echo e(old('description')); ?></textarea>
                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            
                            
                                <button type="submit" class="btn btn-primary text-right">Enviar</button>
                            

                            </form>

                        </div>

                    </div>

                    

                </div>

            </div>

        </section>

    <?php endif; ?>

    <footer id="footer" class="py-5">

        <div class="container">

            <div class="row">

                <div class="col-lg-5 col-md-6">
                    <a href="" class="logo-footer">
                        <img class="img-fluid w-50" src="<?php echo e(asset('assets/images/grupo-ative-360-branco.png')); ?>"
                            alt="">
                    </a>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="contato">
                        <ul>
                            <li>
                                <a>
                                    <i class="fab fa-whatsapp"></i>
                                    <span>+55 (11) 9 9869 0515</span>
                                </a>
                            </li>
                            <li>
                                <a>
                                    <i class="fas fa-envelope"></i>
                                    <span>jaison@grupoative360.com.br</span>
                                </a>
                            </li>
                        </ul>
                    </div>

                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="social-media">
                        <ul>
                            <li>
                                <a href="#" target="_blank"><i class="fab fa-facebook-square"></i></a>
                            </li>
                            <li>
                                <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/5.4.5/js/swiper.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-steps/1.1.0/jquery.steps.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>

    <script src="<?php echo e(asset('/assets/js/app.js')); ?> "></script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\grupoative\resources\views/layouts/app.blade.php ENDPATH**/ ?>