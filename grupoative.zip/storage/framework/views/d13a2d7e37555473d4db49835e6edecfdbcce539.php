<?php $__env->startSection('title', '- Checkout'); ?>

<?php $__env->startSection('content'); ?>

    <div id="checkout">

        <div class="page-title-content">
            <h1>Confira mais uma vez</h1>
            <h5><a href="">Home</a> <span>/</span> <a href="<?php echo e(route('placas.index')); ?>">Placas</a> <span>/</span> Checkout</h5>
        </div>

        <div class="container">

            <div class="illustration">

                <div class="model" style="background: url(<?php echo e(asset('assets/images/modelo_placa.jpg')); ?>);background-position: top;background-repeat: no-repeat;">

                    <div class="row">

                        <div class="image">
                            <img src="<?php echo e(asset('storage/' . $placa['image'])); ?>" alt="">
                        </div>

                        <div class="text text-center">
                            <h3><?php echo e($placa['name']); ?></h3>
                            <p><i class="fas fa-star"></i> <?php echo e($placa['birthdate']); ?></p>
                            <p><i class="fas fa-cross"></i> <?php echo e($placa['deathdate']); ?></p>
                            <p class="phrase"><?php echo e($placa['phrase']); ?></p>
                        </div>

                    </div>

                </div>
                
                <div class="text-center py-3">
                    <a href="<?php echo e(route('checkout.removePlaca')); ?>" class="btn btn-primary">Excluir Placa</a>
                    <a href="<?php echo e(route('checkout.email')); ?>" class="btn btn-primary">Fazer o Pagamento</a>
                </div>

            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\placas\resources\views/checkout/index.blade.php ENDPATH**/ ?>