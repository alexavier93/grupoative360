<div class="row">

    <?php $__currentLoopData = $molduras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moldura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="col-12 col-lg-4 col-md-4">
            <div class="design-item">
                <input type="radio" name="design" id="design-option-<?php echo e($moldura['id']); ?>" value="<?php echo e($moldura['id']); ?>" class="input-hidden radioSize" required />
                <label for="design-option-<?php echo e($moldura['id']); ?>" class="designOption">
                    <img class="img-fluid" src="<?php echo e(asset('storage/' . $moldura['image'])); ?>" />
                </label>
            </div>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div><?php /**PATH C:\xampp\htdocs\placas\resources\views/placas/molduras.blade.php ENDPATH**/ ?>