<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" href="/docs/4.0/assets/img/favicons/favicon.ico">
    <title>Placas Cemitério <?php echo $__env->yieldContent('title'); ?></title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/5.4.5/css/swiper.min.css" />

    <link href="<?php echo e(asset('/assets/css/app.css')); ?>" rel="stylesheet">


</head>

<body>

    <!-- START NAVBAR SECTION -->
    <header id="header">

        <!--    NAVBAR FOR LARGE SCREEN-->
        <nav id="my-nav1" class="navbar navbar-expand-md navbar-light rounded-bar bg-bar">

            <div class="small-screen">
                <a href="" class="preto"><img class="w-50" src="<?php echo e(asset('/assets/images/logo-placas-cemiterio.jpg')); ?>"
                        alt=""></a>
            </div>

            <div class="container">
                <div class="row no-gutters w-100">
                    <div class="collapse navbar-collapse">
                        <div class="col-3 col-md-2 col-lg-4 text-left p-0">
                            <div class="logo">
                                <a href="<?php echo e(route('home')); ?>" class="preto">
                                    <img class="w-50" src="<?php echo e(asset('/assets/images/logo-placas-cemiterio.jpg')); ?>"
                                        alt="Placas Cemitério"></a>
                            </div>
                        </div>
                        <div class="col-md-8 col-lg-6 p-0">
                            <ul id="primary" class="navbar-nav text-center">

                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('home')); ?>">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link btn" href="<?php echo e(route('placas.index')); ?>">Monte sua placa</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('frases.index')); ?>">Frases</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('contato.index')); ?>">Contato</a>
                                </li>
                            </ul>
                        </div>

                        <div class="col-md-2 text-right p-0">
                            <div class="icons">
                                <a href="<?php echo e(route('checkout.index')); ?>" class="cart">
                                    <i class="fas fa-shopping-cart" title="Carrinho"></i>
                                    <span class="badge badge-pill">
                                        <?php if(session()->has('placa')): ?>
                                            1
                                        <?php else: ?>
                                            0
                                        <?php endif; ?>
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <a href="javascript:void(0)" class="sidemenu_btn d-md-none" id="sidemenu_toggle">
                <span></span>
                <span></span>
                <span></span>
            </a>

            <a class="shopping-cart d-md-none" href="">
                <i class="fas fa-shopping-cart" title="Carrinho"></i>
                <span class="badge badge-pill badge-dark">1</span>
            </a>
        </nav>

        <!--Side Nav-->
        <div class="side-menu hidden">
            <div class="inner-wrapper">
                <span class="btn-close" id="btn_sideNavClose"><i></i><i></i></span>
                <nav class="side-nav w-100">
                    <ul class="navbar-nav">

                        <li class="nav-item">
                            <a class="nav-link scroll" href="">porta máscaras</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link scroll" href="">trocas e devoluções</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link scroll" href="">contato</a>
                        </li>

                        <li class="icons">
                            <a href="">
                                <i class="fas fa-shopping-cart" title="Carrinho"></i>
                                <span class="badge badge-pill badge-dark">1</span>
                            </a>
                            <a href="" title="Entre ou Cadastre-se"><i class="fas fa-user"></i></a>
                        </li>
                    </ul>
                </nav>

                <div class="side-footer w-100">
                    <div class="banner-icons">
                        <a href="#"><i class="lab la-facebook-f icons"></i></a>
                        <a href="#"><i class="lab la-twitter icons"></i></a>
                        <a href="#"><i class="lab la-instagram icons"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <a id="close_side_menu" href="javascript:void(0);"></a>
        <!-- End side menu -->
    </header>
    <!-- Header -->

    <main role="main">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer id="footer" class="py-5">

        <div class="container">

            <div class="row">

                <div class="col-lg-5 col-md-6">

                    <div class="footer-about">
                        <a href="">
                            <img class="img-fluid w-50" src="<?php echo e(asset('assets/images/footer-logo.jpg')); ?>" alt="">
                        </a>

                        <p class="py-3">Lorem ipsum dolor sitamet,cons adipiscing elit, sed do eiusmod te incididunt ut
                            labore et
                            dolore Lorem ipsum dolor sitamet,cons adipiscing dolore Lorem ipsum dolor.</p>

                        <div class="social-media">
                            <ul>
                                <li>
                                    <a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a>
                                </li>
                                <li>
                                    <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="contact">
                        <h3>Entre em Contato</h3>

                        <ul>
                            <li class="pl-0">
                                <a href="tel:Phone:+822456974">
                                    <i class="flaticon-call"></i>
                                    <span>Telefone:</span>
                                    (00) 9232-9323
                                </a>
                            </li>

                            <li class="pl-0">
                                <a href="mailto:hello@surety.com">
                                    <i class="flaticon-email"></i>
                                    <span>Email:</span>
                                    contato@placas.com.br
                                </a>
                            </li>

                            <li>
                                <i class="flaticon-maps-and-flags"></i>
                                <span>Endereço:</span>
                                123, Western Road, Melbourne Australia
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="menu">
                        <h3>Service Links</h3>

                        <ul>
                            <li>
                                <a href="#">
                                    Frases
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    Fale Conosco
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    A Empresa
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    Política de Privacidade
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    Política de Troca e Devolução
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    Termos e Condições de Uso
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </footer>

    <div class="copy-right text-center">
        <p>Copyright @2020  Placas de Cemitério</p>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/5.4.5/js/swiper.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-steps/1.1.0/jquery.steps.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>

    <script src="<?php echo e(asset('/assets/js/app.js')); ?> "></script>

    <script>
        $(".radioSize").change(function() {

            if ($(this).is(":checked")) {
                var placa = $(this).val();
            }

            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                url: "<?php echo e(route('placas.getmoldura')); ?>",
                type: 'POST',
                data: 'placa=' + placa,
                dataType: 'text',
                success: function(response) {
                    $(".designs").html(response);
                }
            });

        });

        $(".radioSize").change(function() {

            if ($(this).is(":checked")) {
                var placa = $(this).val();
            }

            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                url: "<?php echo e(route('placas.getmodelo')); ?>",
                type: 'POST',
                data: 'placa=' + placa,
                dataType: 'text',
                success: function(response) {
                    $(".models").html(response);
                }
            });

        });

        $('#cepConsulta').blur(function() {
            var cep = $(this).val();
            consultaCep(cep);
        });

        function consultaCep(cep) {

            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                url: "<?php echo e(route('checkout.consultaCep')); ?>",
                type: 'POST',
                data: 'cep=' + cep,
                dataType: 'json',
                success: function(response) {
                    $('input[name=logradouro]').val(response.logradouro);
                    $('input[name=bairro]').val(response.bairro);
                    $('input[name=cidade]').val(response.cidade);
                    $('input[name=uf]').val(response.uf);
                    $('input[name=numero]').focus();
                }
            });

            return false;

        }

        $(".frete").click(function() {

            var valorFrete = $("input[name=frete]:checked").val();

            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                url: "<?php echo e(route('checkout.calcFrete')); ?>",
                type: 'POST',
                data: 'valorFrete=' + valorFrete,
                dataType: 'json',
                beforeSend: function() {
                    $(".valorFrete").toggle().empty();
                    $(".valorTotal").toggle().empty();
                },
                success: function($data) {
                    $('.valorFrete').toggle().html($data['valorFrete']);
                    $('.valorTotal').toggle().html($data['valorTotal']);
                    $('input[name=valorTotal]').val($data['valorTotal']);
                }

            });

        });

    </script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\placas\resources\views/layouts/app.blade.php ENDPATH**/ ?>