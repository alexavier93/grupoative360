<?php $__env->startSection('title', '- Dados do Comprador'); ?>

<?php $__env->startSection('content'); ?>

    <div id="checkout">

        <div class="container">

            <div class="page-title-content">
                <h1>Finalizar compra</h1>
                <h5><a href="">Home</a> <span>/</span> <a href="<?php echo e(route('checkout.index')); ?>">Checkout</a> <span>/</span> Autenticação</h5>
            </div>

            <div class="customer">

                <div class="row">

                    <div class="col-md-6 offset-md-3 col-sm-12">
    
                        <div class="card">
    
                            <div class="card-body">
    
                                <h5 class="card-title">Para finalizar a compra, informe seu e-mail.</h5>
    
                                <form action="<?php echo e(route('checkout.customerAuth')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>

                                    <div class="mb-3">
                                        <label>Email</label>
                                        <input type="email" class="form-control" name="email" required>
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                           
                                    <button type="submit" class="btn btn-primary">Continuar</button>
    
                                </form>
    
                            </div>
    
                        </div>
    
                    </div>
    
     
                </div>
    

            </div>


        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\placas\resources\views/checkout/email.blade.php ENDPATH**/ ?>