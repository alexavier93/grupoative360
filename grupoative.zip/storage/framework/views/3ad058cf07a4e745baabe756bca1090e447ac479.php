

<?php $__env->startSection('content'); ?>

    <!-- Page Heading -->
    <div class="page-header-content py-3">

        <div class="d-sm-flex align-items-center justify-content-between">
            <h1 class="h3 mb-0 text-gray-800">Mensagens</h1>
        </div>

        <ol class="breadcrumb mb-0 mt-4">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.messages.index')); ?>">Mensagens</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e($message->subject); ?></li>
        </ol>

    </div>

    <!-- Content Row -->
    <div class="row">

        <!-- Content Column -->
        <div class="col-xl-12 col-lg-12 mb-4">

            <!-- Project Card Example -->
            <div class="card shadow mb-4">

                <div class="card-header">
                    <span class="m-0 font-weight-bold text-primary">Enviado - <?php echo e($message->created_at->format('d/m/Y')); ?></span>
                    <a href="javascript:;" data-toggle="modal" data-id='<?php echo e($message->id); ?>' data-target="#modalDelete" class="btn btn-sm btn-danger float-right">Excluir</a>
                </div>

                <div class="card-body p-5">

                    <div class="col-9">

                        <p class="lead"><?php echo e($message->name); ?></p>

                        <div class="font-weight-bold"><?php echo e($message->email); ?></div>
                        <div class="font-weight-bold"><?php echo e($message->phone); ?></div>

                        <p class="my-2"><em><?php echo e($message->description); ?></em></p>

                    </div>



                </div>


            </div>

        </div>

    </div>

    <!-- Modal -->
    <div class="modal fade" id="modalDelete" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-body text-center">
                    <h5 class="py-3 m-0">Tem certeza que deseja excluir este registro?</h5>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Fechar</button>
                    <form action="<?php echo e(route('admin.messages.delete')); ?>" method="post" class="float-right">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" id="id" name="id" value="<?php echo e($message->id); ?>">
                        <button type="submit" class="btn btn-danger btn-sm">Excluir</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\placas\resources\views/admin/messages/show.blade.php ENDPATH**/ ?>